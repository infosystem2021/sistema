-- Dump de la Base de Datos
-- Fecha: domingo 03 marzo 2019 - 21:13:15
--
-- Version: 1.1.1, del 03-03-2019 , insidephp@gmail.com
-- Soporte y Updaters: http://insidephp.sytes.net
--
-- Host: `localhost`    Database: `sistema`
-- ------------------------------------------------------
-- Server version	5.7.17-log

--
-- Table structure for table `equipos`
--

DROP TABLE IF EXISTS equipos;
CREATE TABLE `equipos` (
  `codigo` int(50) NOT NULL AUTO_INCREMENT,
  `departamento` varchar(200) NOT NULL,
  `tipo` varchar(200) NOT NULL,
  `sistema` varchar(200) NOT NULL,
  `siap` varchar(200) NOT NULL,
  `falla` varchar(200) NOT NULL,
  `traido` varchar(200) NOT NULL,
  `recibido` varchar(200) NOT NULL,
  `reparado` varchar(200) NOT NULL,
  `entregado` varchar(200) NOT NULL,
  `entrada` date NOT NULL,
  `salida` date NOT NULL,
  `observacion` varchar(500) NOT NULL,
  PRIMARY KEY (`codigo`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `equipos`
--

LOCK TABLES equipos WRITE;
INSERT INTO equipos VALUES('4', 'consejo', 'escritorio', 'windows 7', 'no', 'no enciende', 'consejal', 'benavides', 'benavides', 'benavides', '2019-02-18', '0000-00-00', '');
INSERT INTO equipos VALUES('5', 'personal', 'escritorio', 'windows 7', 'no', 'actualizacion programa', 'jose', 'jose', 'jose', '', '2019-02-18', '0000-00-00', 'equipo de biometrico');
UNLOCK TABLES;


--
-- Table structure for table `impresoras`
--

DROP TABLE IF EXISTS impresoras;
CREATE TABLE `impresoras` (
  `codigo` int(50) NOT NULL AUTO_INCREMENT,
  `departamento` varchar(200) NOT NULL,
  `tipo` varchar(200) NOT NULL,
  `marca` varchar(200) NOT NULL,
  `enciende` varchar(200) NOT NULL,
  `cable_c` varchar(200) NOT NULL,
  `cable_usb` varchar(200) NOT NULL,
  `toner` varchar(200) NOT NULL,
  `falla` varchar(200) NOT NULL,
  `traido` varchar(200) NOT NULL,
  `recibido` varchar(200) NOT NULL,
  `reparado` varchar(200) NOT NULL,
  `entregado` varchar(200) NOT NULL,
  `entrada` date NOT NULL,
  `salida` date NOT NULL,
  `observacion` varchar(800) NOT NULL,
  PRIMARY KEY (`codigo`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `impresoras`
--

LOCK TABLES impresoras WRITE;
UNLOCK TABLES;


--
-- Table structure for table `ip`
--

DROP TABLE IF EXISTS ip;
CREATE TABLE `ip` (
  `ip` varchar(200) NOT NULL,
  `departamento` varchar(200) NOT NULL,
  `equipo` varchar(200) NOT NULL,
  `sistema` varchar(200) NOT NULL,
  `siap` varchar(100) NOT NULL,
  `usuario` varchar(200) NOT NULL,
  `clave` varchar(200) NOT NULL,
  `observacion` varchar(800) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ip`
--

LOCK TABLES ip WRITE;
INSERT INTO ip VALUES('192.168.0.209', 'informatica', 'vit', 'canaima 5', 'no', 'cesar', 'infar2015', 'ninguna');
INSERT INTO ip VALUES('192.168.0.239', 'informatica', 'vit', 'canaima 5', 'si', 'informaticajef', 'infar2015', 'ninguna');
INSERT INTO ip VALUES('192.168.0.227', 'informatica', 'vit', 'canaima 5', 'no', 'informatica', '123456', 'ninguna');
UNLOCK TABLES;


--
-- Table structure for table `login`
--

DROP TABLE IF EXISTS login;
CREATE TABLE `login` (
  `id` int(50) NOT NULL AUTO_INCREMENT,
  `user` varchar(200) NOT NULL,
  `passadmin` varchar(100) NOT NULL,
  `pass` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login`
--

LOCK TABLES login WRITE;
INSERT INTO login VALUES('2', 'cesar', '63982e54a7aeb0d89910475ba6dbd3ca6dd4e5a1', '63982e54a7aeb0d89910475ba6dbd3ca6dd4e5a1');
INSERT INTO login VALUES('3', 'root', '2e08705154f3f20694db8c5e2787412450ed1af6', '67a74306b06d0c01624fe0d0249a570f4d093747');
UNLOCK TABLES;


--
-- Table structure for table `monitores`
--

DROP TABLE IF EXISTS monitores;
CREATE TABLE `monitores` (
  `codigo` int(50) NOT NULL AUTO_INCREMENT,
  `departamento` varchar(200) NOT NULL,
  `tipo` varchar(200) NOT NULL,
  `marca` varchar(200) NOT NULL,
  `enciende` varchar(200) NOT NULL,
  `cable_c` varchar(200) NOT NULL,
  `cable_vga` varchar(200) NOT NULL,
  `falla` varchar(200) NOT NULL,
  `traido` varchar(200) NOT NULL,
  `recibido` varchar(200) NOT NULL,
  `reparado` varchar(200) NOT NULL,
  `entregado` varchar(200) NOT NULL,
  `entrada` date NOT NULL,
  `salida` date NOT NULL,
  `observacion` varchar(800) NOT NULL,
  PRIMARY KEY (`codigo`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `monitores`
--

LOCK TABLES monitores WRITE;
UNLOCK TABLES;


--
-- Table structure for table `reporte`
--

DROP TABLE IF EXISTS reporte;
CREATE TABLE `reporte` (
  `fecha` date NOT NULL,
  `reporte` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `reporte`
--

LOCK TABLES reporte WRITE;
INSERT INTO reporte VALUES('2019-02-17', '1 este es el primer reporte e dia\r\n2 se reparo una laptop y se le instalo un antivirus');
INSERT INTO reporte VALUES('2019-02-17', 'fdjggfgflkjggklglgkgÃ±ldgkdÃ±lgkdgÃ±lkgdkcsglÃ±dsgkdslÃ±gkdÃ±ldkgdsÃ±lgkgÃ±dslgkdgÃ±lgkdÃ±lgdkgÃ±l');
UNLOCK TABLES;



-- Dump de la Base de Datos Completo.